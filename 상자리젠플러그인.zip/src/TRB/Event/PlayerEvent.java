package TRB.Event;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Chest;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import TRB.ChestRG.Cs;
import TRB.ChestRG.MainClass;
import TRB.Command.CommandUseB;
import TRB.Utils.RespawnChestCheck;
import TRB.Utils.SaveAndLoad;
import TRB.Utils.Utf8YamlConfiguration;


public class PlayerEvent implements Listener
{
	@EventHandler
	public void onPlayerjoin(PlayerJoinEvent e)
	{
		e.setJoinMessage(ChatColor.GOLD + "[Trumble Server]  " + ChatColor.GREEN + e.getPlayer().getName() + "님이 전장에 접속 하셧습니다.");
	}
	@EventHandler
	public void onPlayerExit(PlayerQuitEvent e)
	{
		e.setQuitMessage(ChatColor.GOLD + "[Trumble Server]  " + ChatColor.RED + e.getPlayer().getName() + "님이 전장에 접속 하셧습니다.");
	}
	@EventHandler
	public void onChestSetting(InventoryCloseEvent e)
	{
		if((CommandUseB.PlayerUseCommand) && CommandUseB.PlayerName == e.getPlayer().getName())
		{
				Inventory inv = e.getInventory();
				SaveAndLoad.saves(inv,CommandUseB.ChestName,CommandUseB.ChestName);
				CommandUseB.PlayerUseCommand = false;
				CommandUseB.PlayerName = "";
				CommandUseB.ChestName = "";
				MainClass.cns.put(CommandUseB.ChestName, SaveAndLoad.Loads(e.getInventory().getName()));
				e.getPlayer().sendMessage(Cs.Tag + "성공적으로 저장되엇습니다");
		}
	}
	@EventHandler
	public void onPlayerBlockClick(PlayerInteractEvent e) throws FileNotFoundException, IOException, InvalidConfigurationException
	{
		if((CommandUseB.ChestSetting) && 
		    (e.getClickedBlock().getType() == Material.CHEST) && 
			(e.getAction() == Action.LEFT_CLICK_BLOCK) &&
			(e.getPlayer().getName() == CommandUseB.PlayerName) &&
			(e.getClickedBlock().getType() != Material.AIR)) {
			e.setCancelled(true);
			int Blockx = e.getClickedBlock().getLocation().getBlockX();
			int Blocky = e.getClickedBlock().getLocation().getBlockY();
			int Blockz = e.getClickedBlock().getLocation().getBlockZ();
			SaveAndLoad.LocationSave(Blockx,Blocky,Blockz,e.getClickedBlock().getWorld());
			CommandUseB.ChestSetting = false;
			CommandUseB.PlayerName = "";
			e.getPlayer().sendMessage(Cs.Tag + "[X:" + Blockx + " Y:" + Blocky + " Z:" + Blockz + "]지정된 좌표를 추가하엿습니다");
		}
		else if(e.getAction() != Action.LEFT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_AIR && (e.getClickedBlock().getType() == Material.CHEST)){
			int Blockx = e.getClickedBlock().getLocation().getBlockX();
			int Blocky = e.getClickedBlock().getLocation().getBlockY();
			int Blockz = e.getClickedBlock().getLocation().getBlockZ();
			File f = new File(CommandUseB.lf,"X" + Blockx + "Y" + Blocky + "Z" + Blockz + ".dat");
			if(f.exists())
			{
				if((RespawnChestCheck.Check(e.getClickedBlock(),e.getClickedBlock().getWorld()) == Material.CHEST))
				{
					e.setCancelled(true);
					int Maxval = CommandUseB.f.listFiles().length - 1;
					int filerandom = (int) (Math.random() * Maxval + 0 );
					YamlConfiguration sac = new Utf8YamlConfiguration();
					File[] ac = CommandUseB.f.listFiles();
					sac.load(ac[filerandom]);
					for(ItemStack is : MainClass.cns.get(sac.getString("Name")).getContents())
					{
						if(is != null){ ((Chest) e.getClickedBlock().getState()).getBlockInventory().addItem(is); }
					}
					e.getClickedBlock().setType(Material.AIR);
				}
			}	
		}
	}
}
