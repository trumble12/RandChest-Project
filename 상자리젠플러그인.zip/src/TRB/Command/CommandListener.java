package TRB.Command;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

import TRB.ChestRG.Cs;
import TRB.ChestRG.MainClass;
import TRB.ChestRegen.Respawn;
import TRB.Command.CommandUseB;
import TRB.Utils.Utf8YamlConfiguration;
public class CommandListener 
{
	public boolean CmdListener(CommandSender sender,String Cmd,String[] cmdss,JavaPlugin pl)
	{
		if (!(sender instanceof Player)) {System.out.println("실행창에서 사용하실수 없는 명령어 입니다");return false;}
		Player p = (Player)sender;
		if (cmdss.length == 0) { 
								 p.sendMessage(Cs.Tag + "[명령어 목록]");
								 p.sendMessage(Cs.Tag + "/랜덤상자 설정");
								 p.sendMessage(Cs.Tag + "/랜덤상자 해제 [준비중]");
								 p.sendMessage(Cs.Tag + "/랜덤상자 삭제 <상자이름> [준비중]");
								 p.sendMessage(Cs.Tag + "/랜덤상자 만들기 <상자이름>");
								 p.sendMessage(Cs.Tag + "/랜덤상자 수정 <상자이름>");
								 p.sendMessage(Cs.Tag + "/랜덤상자 모두리젠");
								 p.sendMessage(Cs.Tag + "/랜덤상자 목록");
								 p.sendMessage(Cs.Tag + "/랜덤상자 정보 <상자이름>");return false;}
		if (Cmd.equals("랜덤상자") && cmdss[0].equals("만들기")) {  return ChestCreate(p,cmdss);  }
		if (Cmd.equals("랜덤상자") && cmdss[0].equals("수정")) {  return ChestEdit(p,cmdss);  }
		if (Cmd.equals("랜덤상자") && cmdss[0].equals("설정")) { return ChestSetting(p,cmdss); }
		if (Cmd.equals("랜덤상자") && cmdss[0].equals("목록")) { return ChestList(p,cmdss); }
		if (Cmd.equals("랜덤상자") && cmdss[0].equals("모두리젠")) { return Chestregen(p,cmdss); }
		return true;
	}
	public boolean ChestCreate(Player p,String[] cmd)
	{
		if (cmd.length == 1) { p.sendMessage(Cs.error + "ERROR 상자이름을 입력후 사용하십시오"); return false;}
		else if(CommandUseB.PlayerUseCommand == true) { p.sendMessage(Cs.error + "이미 명령어를 사용중인 사람이 있습니다"); return false; }
		else if(cmd.length == 2 && cmd[0].equalsIgnoreCase("만들기")) {
			File check = new File(CommandUseB.f,cmd[1] + ".dat");
			if (check.exists()) {p.sendMessage(Cs.error + "렌덤상자가 이미 있습니다 수정을원하실경우 /렌덤상자 수정 을 입력하십시오"); return false;}
			Inventory inv = Bukkit.getServer().createInventory(null,9,cmd[1]);
			CommandUseB.PlayerUseCommand = true;
			CommandUseB.PlayerName = p.getName();
			CommandUseB.ChestName = cmd[1];
			p.openInventory(inv);
			return true;
		}
		else { p.sendMessage(Cs.error + "ERROR 정확한 명령어를 입력하십시오"); return false; }
	}
	public boolean ChestEdit(Player p,String cmd[])
	{
		if (cmd.length != 2) { p.sendMessage(Cs.error + "ERROR 상자이름을 입력후 사용하십시오"); return false;}
		else if(CommandUseB.PlayerUseCommand == true) { p.sendMessage(Cs.error + "이미 명령어를 사용중인 사람이 있습니다"); return false; }
		else if(cmd.length == 2 && cmd[0].equalsIgnoreCase("수정")) {
			File check = new File(CommandUseB.f,cmd[1] + ".dat");
			if (!check.exists()) {p.sendMessage(Cs.error + "랜덤상자가 존제하지 않습니다"); return false;}
			CommandUseB.PlayerUseCommand = true;
			CommandUseB.PlayerName = p.getName();
			CommandUseB.ChestName = cmd[1];
			Inventory editinv = MainClass.cns.get(CommandUseB.ChestName);
			p.openInventory(editinv);
			return true;
		}
		else { p.sendMessage(Cs.error + "ERROR 정확한 명령어를 입력하십시오"); return false; }
	}
	public boolean ChestSetting(Player p,String cmd[])
	{
		if(cmd.length == 1)
		{
			if (CommandUseB.ChestSetting) { p.sendMessage(Cs.Tag + "이미 명령어가 실행중입니다 상자를 클릭하여 상자를 설정하여주십시오."); }
			CommandUseB.ChestSetting = true;
			CommandUseB.PlayerName = p.getName();
			p.sendMessage(Cs.Tag + "렌덤상자 셋팅이 준비되엇습니다 상자를 클릭하여 지정해주십시오.");
		}
		else
		{
			p.sendMessage(Cs.error + "ERROR 정확한 명령어를 입력하십시오");
			return false;
		}
		return false;
	}
	public boolean ChestList(Player p,String cmd[])
	{
		if(cmd.length == 1)
		{
			
			p.sendMessage(Cs.Tag + "[랜덤상자 목록]");
			for(File fp : CommandUseB.f.listFiles())
			{
				YamlConfiguration sac = new Utf8YamlConfiguration();
				try {
					sac.load(fp);
				} catch (IOException | InvalidConfigurationException e) { Bukkit.getConsoleSender().sendMessage("로딩중 오류발견"); }
				String Name = (String) sac.get("Name");
				p.getPlayer().sendMessage(Cs.Tag + Name);
			}
		}
		return false;
	}
	public boolean Chestregen(Player p,String cmd[])
	{
		if(cmd.length == 1)
		{
			Respawn.respawn();
			p.sendMessage(Cs.Tag + "[모든상자가 리스폰 되었습니다]");
			
		}
		return false;
	}
}
