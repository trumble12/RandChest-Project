package TRB.Command;

import java.io.File;

public class CommandUseB {
	public static Boolean PlayerUseCommand = false;
	public static Boolean ChestSetting = false;
	public static String PlayerName = "";
	public static String ChestName = "";
	public static File f;
	public static File lf;
}
