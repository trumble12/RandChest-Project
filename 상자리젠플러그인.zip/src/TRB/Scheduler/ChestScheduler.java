package TRB.Scheduler;

import org.bukkit.plugin.java.JavaPlugin;

import TRB.ChestRegen.Respawn;

public class ChestScheduler {
	public static void respawn(final JavaPlugin plg)
	{
		plg.getServer().getScheduler().scheduleSyncRepeatingTask(plg,new Runnable() {
			@Override
			public void run() {
				Respawn.respawn();
			}
		},0L,900L);
	}
	
}
