package TRB.ChestRG;

import org.bukkit.ChatColor;

public class Cs {
	public final static String Tag= ChatColor.AQUA + "[TRB] " + ChatColor.GREEN;
	public final static String error= ChatColor.RED + "[에러] " + ChatColor.GREEN;
}
