package TRB.ChestRG;

import java.io.File;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

import TRB.Command.CommandListener;
import TRB.Command.CommandUseB;
import TRB.Event.PlayerEvent;
import TRB.Scheduler.ChestScheduler;
import TRB.Utils.SaveAndLoad;

public class MainClass extends JavaPlugin{
	public static HashMap<String, Inventory> cns = new HashMap<String,Inventory>();
	@Override
	
	public void onEnable()
	{
		
		Bukkit.getPluginManager().registerEvents(new PlayerEvent(), this);
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA +  "◇■◇■◇■[렌덤상자]■◇■◇■◇");
		Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN +  "◇  정상적으로 구동 되엿습니다  ◇ ");
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA +  "◇■◇■◇■◇■◇■◇■◇■◇■◇");
		saveConfig();
		File rc = new File(getDataFolder(),"\\리젠목록\\");
		File lrc = new File(getDataFolder(),"\\위치\\");
		CommandUseB.f = rc;
		CommandUseB.lf = lrc;
		if(!rc.exists()){rc.mkdir();}
		if(!lrc.exists()){lrc.mkdir();}
		for(File file : rc.listFiles())
		{
			cns.put(SaveAndLoad.Loads2(file).getName(), SaveAndLoad.Loads2(file));
		}
		ChestScheduler.respawn(this);
	}
	@Override
	public void onDisable()
	{
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA +  "◇■◇■◇■[렌덤상자]■◇■◇■◇");
		Bukkit.getConsoleSender().sendMessage(ChatColor.RED +  "◇        정상종료 완료         ◇");
		Bukkit.getConsoleSender().sendMessage(ChatColor.AQUA +  "◇■◇■◇■◇■◇■◇■◇■◇■◇");
	}
    public boolean onCommand(CommandSender Sender, Command command, String Cmd, String[] Cmdss) {
        CommandListener listener = new CommandListener();
        return listener.CmdListener(Sender, Cmd, Cmdss, this);
    }
}
