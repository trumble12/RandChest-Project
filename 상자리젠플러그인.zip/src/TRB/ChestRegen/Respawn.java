package TRB.ChestRegen;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import TRB.Command.CommandUseB;
import TRB.Utils.Utf8YamlConfiguration;

public class Respawn {
	public static void respawn()
	{
		for(File ac : CommandUseB.lf.listFiles())
		{
			YamlConfiguration yam = new Utf8YamlConfiguration();
			try {yam.load(ac);} catch (IOException | InvalidConfigurationException e) {e.printStackTrace();}
			ConfigurationSection loc = yam.getConfigurationSection("Loction");
			Location loac = new Location(Bukkit.getWorld("World"), loc.getDouble("Xpos"), loc.getDouble("Ypos"), loc.getDouble("Zpos"));
			if (loac.getBlock().getType() != Material.CHEST)
			{
				loac.getBlock().setType(Material.CHEST);
			}
		}
	}
}
