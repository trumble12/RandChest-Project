package TRB.Utils;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import TRB.Command.CommandUseB;

public class SaveAndLoad {
	public static void saves(Inventory inv,String Name,String chestName)
	{
		YamlConfiguration sac = new Utf8YamlConfiguration();
		int size = inv.getSize();
		sac.set("size", Integer.valueOf(size));
		sac.set("Name", chestName);
		ConfigurationSection item = sac.createSection(chestName);
		for(int count = 0;count < size;count++)
		{
			ItemStack it = inv.getItem(count);
			if(it != null ){item.set(String.valueOf(count),it);}
		}
		try { File fs = new File(CommandUseB.f,chestName + ".dat"); sac.save(fs); } 
		catch (IOException e) { Bukkit.getConsoleSender().sendMessage("저장중 오류발견"); }
	}
	public static Inventory Loads(String Name)
	{
		
		File itemfile = new File(CommandUseB.f, Name + ".dat");
		YamlConfiguration sac = new Utf8YamlConfiguration();
		try {
			sac.load(itemfile);
		} catch (IOException | InvalidConfigurationException e) { Bukkit.getConsoleSender().sendMessage("로딩중 오류발견"); }
		ConfigurationSection item = sac.getConfigurationSection(Name);
		Inventory fixinv = Bukkit.createInventory(null, 9,Name);
		for(int count = 0; count<9 ; count++)
		{
			if (item.isItemStack(String.valueOf(count))) { fixinv.setItem(count, item.getItemStack(String.valueOf(count))); }
		}
		return fixinv;
	}
	public static Inventory Loads2(File Filename)
	{
		File itemfile = Filename;
		YamlConfiguration sac = new Utf8YamlConfiguration();
		try {
			sac.load(itemfile);
		} catch (IOException | InvalidConfigurationException e) { Bukkit.getConsoleSender().sendMessage("로딩중 오류발견"); }
		String Name = (String) sac.get("Name");
		Inventory crinv = Bukkit.createInventory(null, 9,Name);
		ConfigurationSection item = sac.getConfigurationSection(Name);
		for(int count = 0; count<9 ; count++)
		{
			if (item.isItemStack(String.valueOf(count))) { crinv.setItem(count, item.getItemStack(String.valueOf(count))); }
		}
		return crinv;
	}
	public static void LocationSave(int blockx,int blocky,int blockz,World world)
	{
		YamlConfiguration sac = new Utf8YamlConfiguration();
		ConfigurationSection loction = sac.createSection("Loction");
		loction.set("Xpos", blockx);
		loction.set("Ypos", blocky);
		loction.set("Zpos", blockz);
		try { File fs = new File(CommandUseB.lf,"X" + blockx + "Y" + blocky + "Z" + blockz + ".dat"); sac.save(fs); } 
		catch (IOException e) { Bukkit.getConsoleSender().sendMessage("저장중 오류발견"); }
	}
	public void respawnLoction()
	{
		
	}
}
