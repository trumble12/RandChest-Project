package TRB.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import TRB.Command.CommandUseB;

public class RespawnChestCheck {
	public static Material Check(Block clickblock,World world) throws FileNotFoundException, IOException, InvalidConfigurationException
	{
		YamlConfiguration sac = new Utf8YamlConfiguration();
		File bl = new File(CommandUseB.lf,"X" + (int)clickblock.getLocation().getBlockX() + "Y" + (int)clickblock.getLocation().getBlockY() + "Z" + (int)clickblock.getLocation().getBlockZ() + ".dat");
		sac.load(bl);
		ConfigurationSection loc = sac.getConfigurationSection("Loction");
		Location block = new Location(clickblock.getWorld(), clickblock.getLocation().getBlockX(), clickblock.getLocation().getBlockY(),clickblock.getLocation().getBlockZ());
		Location SaveBlock = new Location(clickblock.getWorld(),loc.getDouble("Xpos"), loc.getDouble("Ypos"),loc.getDouble("Zpos"));
		if (block == SaveBlock && SaveBlock.getBlock().getType() == Material.CHEST) { return SaveBlock.getBlock().getType(); }
		else { return SaveBlock.getBlock().getType(); }
	}
}
